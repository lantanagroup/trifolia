To build the IG, download the FHIR IG Publisher JAR from http://build.fhir.org/downloads.html
The direct link to the FHIR IG Publisher JAR is: http://build.fhir.org/org.hl7.fhir.igpublisher.jar
Place the JAR file in the same directory as the other files extracted from the FHIR Build package, and run one of the "RunXXX.bat" batch files.